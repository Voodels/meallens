package com.meallens;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeallensApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeallensApplication.class, args);
	}

}
